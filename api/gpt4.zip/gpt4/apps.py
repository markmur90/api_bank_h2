from django.apps import AppConfig


class Gpt4Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.gpt4'
